+++
authors = [
    "Hugo Authors",
]
title = "Image Gallery"
date = "2020-01-02"
description = "Showcase the image gallery feature."
tags = [
    "gallery",
    "lightbox",
]
images = [
    "image-gallery.jpg",
]
+++

Showcase the image gallery feature using the `Figure` shortcode. Images using the `Figure` shortcode will be rendered through [`ekko-lightbox`](https://ashleydw.github.io/lightbox/).
<!--more-->

{{< figure src="https://unsplash.it/1200/768.jpg?image=251" >}}
{{< figure src="https://unsplash.it/1200/768.jpg?image=252" >}}
{{< figure src="https://unsplash.it/1200/768.jpg?image=253" >}}
